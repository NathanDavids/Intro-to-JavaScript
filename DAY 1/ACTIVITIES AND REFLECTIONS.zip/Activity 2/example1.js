function basicFunction () {  //the name of the function is basicFunction
    alert ("Hello JavaScripters!");  //an alert box is dislayed when the page loads
}
basicFunction(); //calling the function